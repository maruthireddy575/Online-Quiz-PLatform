# Frontend

Instructions for running the frontend are in this folder. They mostly follow a basic Vite/React setup.

> **Charts**
> The analytics page now uses **Chart.js** with the React wrapper. Install the libraries before starting the app:
>
> ```bash
> cd frontend
> npm install chart.js react-chartjs-2 chartjs-plugin-datalabels
> ```
>
> The graphs display a bar chart and pie chart for individual attempts and a pie chart for class‑average data.
