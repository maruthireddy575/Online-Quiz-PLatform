import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// some dependencies (chartjs-plugin-datalabels) ship as CommonJS
// and can trip Vite's optimization. Explicitly include them so they
// are pre-bundled correctly.
export default defineConfig({
  plugins: [react()],
  optimizeDeps: {
    include: ['chart.js', 'chartjs-plugin-datalabels']
  }
});
