import React from "react";

const ExplanationBox = ({ explanation }) => {
  // Don't show anything if no explanation exists
  if (!explanation) return null;

  return (
    <div style={{
      marginTop: "16px",
      padding: "16px",
      borderRadius: "12px",
      background: "rgba(59, 130, 246, 0.1)",
      border: "1px solid #3b82f6",
      borderLeft: "4px solid #3b82f6"
    }}>
      <h4 style={{
        margin: "0 0 8px 0",
        color: "#3b82f6",
        fontWeight: "600"
      }}>
        📝 Explanation
      </h4>
      <p style={{
        margin: 0,
        color: "#e5e7eb",
        lineHeight: "1.6",
        whiteSpace: "pre-wrap"
      }}>
        {explanation}
      </p>
    </div>
  );
};

export default ExplanationBox;