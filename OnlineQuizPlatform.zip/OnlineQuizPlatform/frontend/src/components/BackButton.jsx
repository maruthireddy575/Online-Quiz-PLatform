import React from "react";

export default function BackButton({ onClick }) {
  return (
    <button
      type="button"
      onClick={onClick}
      style={{
        marginBottom: "12px",
        background: "transparent",
        border: "1px solid rgba(103,232,249,0.35)",
        color: "#67e8f9",
        cursor: "pointer",
        padding: "6px 10px",
        borderRadius: "8px"
      }}
    >
      ← Back
    </button>
  );
}
