import React, { useEffect } from "react";

export default function Toast({ message, duration = 2000, onClose }) {
  useEffect(() => {
    if (!message) return;
    const t = setTimeout(() => {
      onClose && onClose();
    }, duration);
    return () => clearTimeout(t);
  }, [message, duration, onClose]);

  if (!message) return null;

  return (
    <div style={styles.toast} role="status">
      {message}
    </div>
  );
}

const styles = {
  toast: {
    position: "fixed",
    right: "20px",
    top: "20px",
    background: "rgba(7,12,20,0.9)",
    color: "#e6f7ff",
    padding: "10px 14px",
    borderRadius: "10px",
    boxShadow: "0 8px 30px rgba(2,6,23,0.6)",
    zIndex: 99999,
    fontWeight: 700
  }
};
