import React from "react";
import DashboardLayout from "../components/layout/DashboardLayout";
import Sidebar from "../components/layout/Sidebar";

export default function ExampleDashboard({ username, role }) {
  return (
    <DashboardLayout
      sidebar={
        <Sidebar
          username={username}
          role={role}
          onDashboard={() => console.log("Dashboard")}
          onCreateQuiz={() => console.log("Create Quiz")}
          onAttemptQuiz={() => console.log("Attempt Quiz")}
          onViewAttempts={() => console.log("View Attempts")}
          onMyQuizzes={() => console.log("My Quizzes")}
          onLogout={() => console.log("Logout")}
        />
      }
    >
      <div className="animate-slide-in">
        {/* Page Header */}
        <div style={{ marginBottom: "var(--spacing-8)" }}>
          <h1 style={{ 
            fontSize: "var(--font-size-3xl)", 
            fontWeight: "700", 
            color: "var(--text-primary)",
            marginBottom: "var(--spacing-2)"
          }}>
            Multi-Color Dashboard Example
          </h1>
          <p style={{ 
            color: "var(--text-secondary)", 
            fontSize: "var(--font-size-lg)" 
          }}>
            Experience the new professional multi-color theme system
          </p>
        </div>

        {/* Statistics Cards with Different Colors */}
        <div style={{ 
          display: "grid", 
          gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))", 
          gap: "var(--spacing-6)", 
          marginBottom: "var(--spacing-8)" 
        }}>
          <div className="stat-card success animate-fade-in">
            <div className="stat-value">1,284</div>
            <div className="stat-label">Total Quizzes</div>
            <div className="stat-change positive">+12.5%</div>
          </div>

          <div className="stat-card info animate-fade-in" style={{ animationDelay: "0.1s" }}>
            <div className="stat-value">892</div>
            <div className="stat-label">Active Users</div>
            <div className="stat-change positive">+8.2%</div>
          </div>

          <div className="stat-card warning animate-fade-in" style={{ animationDelay: "0.2s" }}>
            <div className="stat-value">456</div>
            <div className="stat-label">Completions</div>
            <div className="stat-change negative">-3.1%</div>
          </div>

          <div className="stat-card danger animate-fade-in" style={{ animationDelay: "0.3s" }}>
            <div className="stat-value">23</div>
            <div className="stat-label">Pending Reviews</div>
            <div className="stat-change positive">+2 new</div>
          </div>
        </div>

        {/* Multi-Color Cards Section */}
        <div style={{ marginBottom: "var(--spacing-8)" }}>
          <h2 style={{ 
            fontSize: "var(--font-size-2xl)", 
            fontWeight: "600", 
            color: "var(--text-primary)",
            marginBottom: "var(--spacing-6)"
          }}>
            Multi-Color Card System
          </h2>

          <div style={{ 
            display: "grid", 
            gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))", 
            gap: "var(--spacing-6)" 
          }}>
            {/* Primary Card */}
            <div className="card card-primary animate-slide-in">
              <div className="card-header">
                <h3 style={{ 
                  fontSize: "var(--font-size-lg)", 
                  fontWeight: "600", 
                  color: "var(--text-primary)",
                  margin: 0 
                }}>
                  Primary Actions
                </h3>
              </div>
              <div className="card-body">
                <p style={{ color: "var(--text-secondary)", marginBottom: "var(--spacing-4)" }}>
                  Main dashboard controls and navigation options.
                </p>
                <div style={{ display: "flex", gap: "var(--spacing-3)" }}>
                  <button className="btn btn-primary">Primary Action</button>
                  <button className="btn btn-outline">Secondary</button>
                </div>
              </div>
            </div>

            {/* Success Card */}
            <div className="card card-success animate-slide-in" style={{ animationDelay: "0.1s" }}>
              <div className="card-header">
                <h3 style={{ 
                  fontSize: "var(--font-size-lg)", 
                  fontWeight: "600", 
                  color: "var(--text-primary)",
                  margin: 0 
                }}>
                  Success Metrics
                </h3>
              </div>
              <div className="card-body">
                <p style={{ color: "var(--text-secondary)", marginBottom: "var(--spacing-4)" }}>
                  Track your successful quiz completions and achievements.
                </p>
                <div style={{ display: "flex", gap: "var(--spacing-3)" }}>
                  <button className="btn btn-success">View Success</button>
                  <span className="badge badge-success">Excellent</span>
                </div>
              </div>
            </div>

            {/* Warning Card */}
            <div className="card card-warning animate-slide-in" style={{ animationDelay: "0.2s" }}>
              <div className="card-header">
                <h3 style={{ 
                  fontSize: "var(--font-size-lg)", 
                  fontWeight: "600", 
                  color: "var(--text-primary)",
                  margin: 0 
                }}>
                  Warnings & Alerts
                </h3>
              </div>
              <div className="card-body">
                <p style={{ color: "var(--text-secondary)", marginBottom: "var(--spacing-4)" }}>
                  Important notifications and system warnings.
                </p>
                <div style={{ display: "flex", gap: "var(--spacing-3)" }}>
                  <button className="btn btn-warning">Review Alerts</button>
                  <span className="badge badge-warning">3 New</span>
                </div>
              </div>
            </div>

            {/* Danger Card */}
            <div className="card card-danger animate-slide-in" style={{ animationDelay: "0.3s" }}>
              <div className="card-header">
                <h3 style={{ 
                  fontSize: "var(--font-size-lg)", 
                  fontWeight: "600", 
                  color: "var(--text-primary)",
                  margin: 0 
                }}>
                  Critical Issues
                </h3>
              </div>
              <div className="card-body">
                <p style={{ color: "var(--text-secondary)", marginBottom: "var(--spacing-4)" }}>
                  Urgent items requiring immediate attention.
                </p>
                <div style={{ display: "flex", gap: "var(--spacing-3)" }}>
                  <button className="btn btn-danger">Fix Now</button>
                  <span className="badge badge-danger">Critical</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Visual Hierarchy Examples */}
        <div style={{ marginBottom: "var(--spacing-8)" }}>
          <h2 style={{ 
            fontSize: "var(--font-size-2xl)", 
            fontWeight: "600", 
            color: "var(--text-primary)",
            marginBottom: "var(--spacing-6)"
          }}>
            Visual Hierarchy - Container Sizes
          </h2>

          {/* Large Container */}
          <div className="container-large animate-fade-in">
            <h3 style={{ 
              fontSize: "var(--font-size-xl)", 
              fontWeight: "600", 
              color: "var(--text-primary)",
              marginBottom: "var(--spacing-4)"
            }}>
              Large Container
            </h3>
            <p style={{ color: "var(--text-secondary)", marginBottom: "var(--spacing-4)" }}>
              Used for main sections and important content areas. Features a subtle background tone and enhanced shadows.
            </p>
            <button className="btn btn-primary">Large Action</button>
          </div>

          {/* Medium Containers */}
          <div style={{ 
            display: "grid", 
            gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))", 
            gap: "var(--spacing-6)", 
            marginBottom: "var(--spacing-6)" 
          }}>
            <div className="container-medium animate-slide-in" style={{ animationDelay: "0.1s" }}>
              <h4 style={{ 
                fontSize: "var(--font-size-lg)", 
                fontWeight: "600", 
                color: "var(--text-primary)",
                marginBottom: "var(--spacing-3)"
              }}>
                Medium Card
              </h4>
              <p style={{ color: "var(--text-secondary)", marginBottom: "var(--spacing-4)" }}>
                White background with medium shadows for standard content cards.
              </p>
              <button className="btn btn-secondary">Medium Action</button>
            </div>

            <div className="container-medium animate-slide-in" style={{ animationDelay: "0.2s" }}>
              <h4 style={{ 
                fontSize: "var(--font-size-lg)", 
                fontWeight: "600", 
                color: "var(--text-primary)",
                marginBottom: "var(--spacing-3)"
              }}>
                Another Medium
              </h4>
              <p style={{ color: "var(--text-secondary)", marginBottom: "var(--spacing-4)" }}>
                Consistent styling across all medium-sized containers.
              </p>
              <button className="btn btn-outline">Outline Action</button>
            </div>
          </div>

          {/* Small Containers */}
          <div style={{ 
            display: "grid", 
            gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", 
            gap: "var(--spacing-4)" 
          }}>
            <div className="container-small animate-fade-in" style={{ animationDelay: "0.3s" }}>
              <h5 style={{ 
                fontSize: "var(--font-size-base)", 
                fontWeight: "600", 
                color: "var(--text-primary)",
                marginBottom: "var(--spacing-2)"
              }}>
                Small Card
              </h5>
              <p style={{ color: "var(--text-secondary)", fontSize: "var(--font-size-sm)" }}>
                Minimal styling for auxiliary information.
              </p>
            </div>

            <div className="container-small animate-fade-in" style={{ animationDelay: "0.4s" }}>
              <h5 style={{ 
                fontSize: "var(--font-size-base)", 
                fontWeight: "600", 
                color: "var(--text-primary)",
                marginBottom: "var(--spacing-2)"
              }}>
                Quick Info
              </h5>
              <p style={{ color: "var(--text-secondary)", fontSize: "var(--font-size-sm)" }}>
                Lightweight and subtle presentation.
              </p>
            </div>

            <div className="container-small animate-fade-in" style={{ animationDelay: "0.5s" }}>
              <h5 style={{ 
                fontSize: "var(--font-size-base)", 
                fontWeight: "600", 
                color: "var(--text-primary)",
                marginBottom: "var(--spacing-2)"
              }}>
                Status
              </h5>
              <p style={{ color: "var(--text-secondary)", fontSize: "var(--font-size-sm)" }}>
                <span className="badge badge-info">Active</span>
              </p>
            </div>
          </div>
        </div>

        {/* Button Showcase */}
        <div className="container-medium animate-slide-in" style={{ animationDelay: "0.6s" }}>
          <h3 style={{ 
            fontSize: "var(--font-size-xl)", 
            fontWeight: "600", 
            color: "var(--text-primary)",
            marginBottom: "var(--spacing-4)"
          }}>
            Button System Showcase
          </h3>
          <p style={{ color: "var(--text-secondary)", marginBottom: "var(--spacing-6)" }}>
            Complete button system with contextual colors and smooth animations.
          </p>
          
          <div style={{ 
            display: "flex", 
            flexWrap: "wrap", 
            gap: "var(--spacing-4)", 
            marginBottom: "var(--spacing-6)" 
          }}>
            <button className="btn btn-primary">Primary</button>
            <button className="btn btn-secondary">Secondary</button>
            <button className="btn btn-success">Success</button>
            <button className="btn btn-warning">Warning</button>
            <button className="btn btn-danger">Danger</button>
            <button className="btn btn-outline">Outline</button>
          </div>

          <div style={{ 
            display: "flex", 
            flexWrap: "wrap", 
            gap: "var(--spacing-4)", 
            alignItems: "center" 
          }}>
            <button className="btn btn-primary btn-sm">Small Primary</button>
            <button className="btn btn-secondary">Default Size</button>
            <button className="btn btn-success btn-lg">Large Success</button>
            <button className="btn btn-warning" disabled>Disabled</button>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
