import React, { useEffect, useState } from "react";
import DashboardLayout from "../../components/layout/DashboardLayout";
import Sidebar from "../../components/layout/Sidebar";
import { theme } from "../../styles/theme";
import ExplanationBox from "../../components/ExplanationBox";

export default function Attempts({
  username,
  onDashboard,
  onAttemptQuiz,
  onViewAttempts,
  onLogout
}) {
  const role = "attempter";
  const [attempts, setAttempts] = useState([]);
  const [selectedAttempt, setSelectedAttempt] = useState(null);

  const formatNumber = (n) => {
    if (n === undefined || n === null) return "-";
    const num = Number(n);
    if (Number.isInteger(num)) return String(num);
    return num.toFixed(2).replace(/\.0+$|0+$/,'').replace(/\.$/, '');
  };

  useEffect(() => {
    if (!username) return;

    // connect to WebSocket server for live updates
    let socket;
    try {
      socket = new WebSocket('ws://localhost:5000');
    } catch (e) {
      socket = null;
    }

    if (socket) {
      socket.addEventListener('message', (ev) => {
        try {
          const msg = JSON.parse(ev.data);
          if (msg.event === 'attempt.updated') {
            const updated = msg.data;
            if (updated && updated.username === username) {
              setAttempts(prev => {
                const found = prev.some(a => a.id === updated.id);
                if (found) return prev.map(a => (a.id === updated.id ? updated : a));
                return [updated, ...prev];
              });
            }
          }
        } catch (err) {
          // ignore parse errors
        }
      });
    }

    return () => {
      try {
        socket && socket.close();
      } catch (e) {}
    };
  }, [username]);

  useEffect(() => {
    if (!username) return;

    fetch(`http://localhost:5000/attempts/user/${username}`)
      .then((res) => res.json())
      .then((data) => {
        console.log("🔥 ALL ATTEMPTS DATA:", data); // Debug all attempts
        setAttempts(data);
      })
      .catch(() => setAttempts([]));
  }, [username]);

  const getQuestionType = (q) => {
    if (q.type) return q.type;

    if (q.correctIndex !== undefined) return "mcq";
    if (Array.isArray(q.correctAnswers)) {
      if (q.correctAnswers.length > 1) return "msq";
      return "mcq";
    }

    return "mcq";
  };

  const formatImage = (img) => {
    if (!img) return null;
    if (img.startsWith("http")) return img;
    const clean = img.startsWith("/") ? img : `/${img}`;
    return `http://localhost:5000${clean}`;
  };

  // Helper to check if answer is correct
  const isAnswerCorrect = (q, userAnswer) => {
    const type = getQuestionType(q);
    
    if (type === "mcq" || type === "image") {
      const correctIndex = q.correctIndex !== undefined
        ? q.correctIndex
        : q.correctAnswers?.[0];
      return userAnswer === correctIndex;
    }
    
    if (type === "msq") {
      const correctAnswers = q.correctAnswers || [];
      return (
        Array.isArray(userAnswer) &&
        correctAnswers.length === userAnswer.length &&
        correctAnswers.every(index => userAnswer.includes(index))
      );
    }
    
    return false;
  };

  // Back button component
  const BackButton = ({ onClick }) => (
    <button
      onClick={onClick}
      style={{
        background: "transparent",
        border: "1px solid rgba(255,255,255,0.2)",
        color: "white",
        padding: "8px 16px",
        borderRadius: "8px",
        marginBottom: "20px",
        cursor: "pointer",
        fontSize: "0.9rem"
      }}
    >
      ← Back to Attempts List
    </button>
  );

  return (
    <DashboardLayout
      sidebar={
        <Sidebar
          username={username}
          role={role}
          onDashboard={onDashboard}
          onAttemptQuiz={onAttemptQuiz}
          onViewAttempts={onViewAttempts}
          onLogout={onLogout}
        />
      }
    >
      {!selectedAttempt ? (
        // ATTEMPTS LIST VIEW
        <>
          <h2 style={styles.title}>Past Attempts</h2>

        {attempts.length === 0 && (
  <p style={{...styles.empty, color: '#00FFFF'}}>No attempts yet.</p>
)}

          {attempts.map((a, index) => (
            <div
              key={index}
              style={styles.attemptCard}
              onClick={() => {
                console.log("🔥 SELECTED ATTEMPT:", a);
                setSelectedAttempt(a);
              }}
            >
              <div style={styles.attemptCardContent}>
                <h3 style={styles.attemptTitle}>{a.quizTitle || "Untitled Quiz"}</h3>
                <p style={styles.attemptMeta}>
                  Score: {formatNumber(a.score)}/{formatNumber(a.total)} | 
                  Date: {new Date(a.timestamp).toLocaleString()}
                </p>
                <div style={styles.difficultyBadgeSmall}>
                  {(a.difficulty || "easy").toUpperCase()}
                </div>
              </div>
            </div>
          ))}
        </>
      ) : (
        // SELECTED ATTEMPT DETAIL VIEW WITH EXPLANATIONS
        <>
          <BackButton onClick={() => setSelectedAttempt(null)} />
          
          <h2 style={styles.title}>{selectedAttempt.quizTitle}</h2>
          <p style={styles.attemptScore}>
            Score: {formatNumber(selectedAttempt.score)}/{formatNumber(selectedAttempt.total)} | 
            Date: {new Date(selectedAttempt.timestamp).toLocaleString()}
          </p>

          {/* Questions with Explanations */}
          <div style={styles.questionsList}>
            {selectedAttempt.questions.map((q, qIndex) => {
              const userAnswer = selectedAttempt.answers?.[qIndex];
              const type = getQuestionType(q);
              const correct = isAnswerCorrect(q, userAnswer);

              return (
                <div key={qIndex} style={styles.reviewCard}>
                  <h4 style={styles.questionHeader}>
                    Q{qIndex + 1}: {q.text}
                  </h4>

                  {q.image && (
                    <img
                      src={formatImage(q.image)}
                      alt="Question"
                      style={styles.questionImage}
                    />
                  )}

                  {/* Your Answer */}
                  <div style={styles.answerBox}>
                    <span style={styles.answerLabel}>Your answer: </span>
<span style={styles.answerValue}>
  {type === "text" ? (
    userAnswer && userAnswer.trim() !== ""
      ? userAnswer
      : "Not answered"
  ) : type === "msq" ? (
    (userAnswer || []).map(i => {
      const opt = q.options[i];
      return typeof opt === "object" ? opt.text : opt;
    }).join(", ") || "Not answered"
  ) : (
    userAnswer !== undefined && userAnswer !== null
      ? (typeof q.options[userAnswer] === "object"
          ? q.options[userAnswer].text
          : q.options[userAnswer])
      : "Not answered"
  )}
  {correct && type !== "text" && (
    <span style={styles.correctMark}> ✓</span>
  )}
</span>
                  </div>

                  {/* Correct Answer (if wrong) */}
                  {!correct && type !== "text" && type !== "msq" && (
                    <div style={styles.correctAnswerBox}>
                      <span style={styles.correctAnswerLabel}>Correct answer: </span>
                      <span style={styles.correctAnswerValue}>
                        {(() => {
                          const correctIndex = q.correctIndex !== undefined
                            ? q.correctIndex
                            : q.correctAnswers?.[0];
                          const correctOpt = q.options[correctIndex];
                          return typeof correctOpt === "object" ? correctOpt.text : correctOpt;
                        })()}
                      </span>
                    </div>
                  )}

                  {!correct && type === "msq" && (
                    <div style={styles.correctAnswerBox}>
                      <span style={styles.correctAnswerLabel}>Correct answer: </span>
                      <span style={styles.correctAnswerValue}>
                        {(q.correctAnswers || []).map(i => {
                          const opt = q.options[i];
                          return typeof opt === "object" ? opt.text : opt;
                        }).join(", ")}
                      </span>
                    </div>
                  )}

                  {/* 🔥 SHOW MANUAL MARKS FOR TEXT QUESTIONS */}
                  {type === "text" &&
                    selectedAttempt.manualMarks &&
                    Object.prototype.hasOwnProperty.call(
                      selectedAttempt.manualMarks,
                      qIndex
                    ) && (
                      <div style={styles.correctAnswerBox}>
                        <span style={styles.correctAnswerLabel}>
                          Marked:
                        </span>
                        <span
                          style={
                            Number(selectedAttempt.manualMarks[qIndex]) > 0
                              ? styles.correct
                              : styles.wrong
                          }
                        >
                          {selectedAttempt.manualMarks[qIndex]} / {q.marks || 1}
                        </span>
                      </div>
                  )}
                  {/* 🔥 EXPLANATION BOX - Shows creator's explanation */}
                  <ExplanationBox explanation={q.explanation} />
                </div>
              );
            })}
          </div>
        </>
      )}
    </DashboardLayout>
  );
}

const styles = {
  title: {
    marginBottom: theme.spacing.lg,
    color: "white",
    fontSize: "1.9rem",
    fontWeight: "600"
  },

  empty: {
    color: theme.colors.muted,
    textAlign: "center",
    padding: "40px"
  },

  attemptCard: {
    background: "rgba(255,255,255,0.08)",
    backdropFilter: "blur(20px)",
    border: "1px solid rgba(255,255,255,0.15)",
    borderRadius: "16px",
    marginBottom: "16px",
    cursor: "pointer",
    transition: "all 0.3s ease",
    position: "relative",
    overflow: "hidden",
    ":hover": {
      transform: "translateX(10px)",
      border: "1px solid rgba(167, 139, 250, 0.5)",
      boxShadow: "0 10px 30px rgba(0,0,0,0.3)"
    }
  },

  attemptCardContent: {
    padding: "20px"
  },

  attemptTitle: {
    color: "white",
    fontSize: "1.2rem",
    fontWeight: "600",
    marginBottom: "8px"
  },

  attemptMeta: {
    color: "rgba(255,255,255,0.7)",
    fontSize: "0.9rem"
  },

  difficultyBadgeSmall: {
    position: "absolute",
    top: "20px",
    right: "20px",
    padding: "4px 12px",
    borderRadius: "20px",
    fontSize: "0.7rem",
    fontWeight: "700",
    letterSpacing: "1px",
    background: "rgba(167, 139, 250, 0.2)",
    color: "#a78bfa",
    border: "1px solid #a78bfa"
  },

  attemptScore: {
    color: "#a78bfa",
    fontSize: "1.1rem",
    marginBottom: "30px",
    padding: "10px 16px",
    background: "rgba(167, 139, 250, 0.1)",
    borderRadius: "8px",
    display: "inline-block"
  },

  questionsList: {
    display: "flex",
    flexDirection: "column",
    gap: "20px"
  },

  reviewCard: {
    background: "rgba(255,255,255,0.05)",
    borderRadius: "12px",
    padding: "20px",
    border: "1px solid rgba(255,255,255,0.1)"
  },

  questionHeader: {
    color: "white",
    fontSize: "1.1rem",
    fontWeight: "600",
    marginBottom: "15px"
  },

  questionImage: {
    width: "220px",
    maxHeight: "160px",
    objectFit: "contain",
    borderRadius: "8px",
    marginBottom: "15px"
  },

  answerBox: {
    background: "rgba(167, 139, 250, 0.1)",
    borderRadius: "8px",
    padding: "12px",
    marginBottom: "10px",
    borderLeft: "3px solid #a78bfa"
  },

  answerLabel: {
    color: "#a78bfa",
    fontWeight: "500",
    marginRight: "8px"
  },

  answerValue: {
    color: "white"
  },

  correctMark: {
    color: "#34d399",
    fontWeight: "bold",
    marginLeft: "4px"
  },

  correctAnswerBox: {
    background: "rgba(52, 211, 153, 0.1)",
    borderRadius: "8px",
    padding: "12px",
    marginBottom: "15px",
    borderLeft: "3px solid #34d399"
  },

  correctAnswerLabel: {
    color: "#34d399",
    fontWeight: "500",
    marginRight: "8px"
  },

  correctAnswerValue: {
    color: "white"
  },

  card: {
    background: "rgba(255,255,255,0.06)",
    backdropFilter: "blur(16px)",
    border: "1px solid rgba(255,255,255,0.15)",
    borderRadius: "16px",
    padding: "20px 20px 20px 70px",
    marginBottom: "16px",
    marginLeft: "0px",
    boxShadow: "0 15px 40px rgba(0,0,0,0.25)",
    position: "relative"
  },

  quizTitle: {
    color: "#67e8f9",
    fontWeight: "600",
    marginBottom: "6px"
  },

  score: {
    color: "#c4b5fd",
    fontWeight: "600",
    marginBottom: "6px"
  },

  time: {
    fontSize: "0.85rem",
    color: "#151517",
    marginBottom: theme.spacing.sm
  },

  question: {
    marginTop: theme.spacing.sm
  },

  questionText: {
    fontWeight: "500",
    color: "white"
  },

  optionImage: {
    width: "160px",
    maxHeight: "120px",
    objectFit: "contain",
    borderRadius: "6px",
    marginTop: "6px",
    marginBottom: "6px"
  },

  correct: {
    color: "#34d399",
    fontWeight: "600",
    textShadow: "0 0 4px rgba(52, 211, 153, 0.6)"
  },

  wrong: {
    color: "#a70808",
    fontWeight: "600",
    textShadow: "0 0 4px rgba(167, 8, 8, 0.6)"
  },

  rowWrapper: {
    position: "relative",
    marginBottom: "28px"
  },

  attemptNumber: {
    position: "absolute",
    left: "12px",
    top: "20px",
    width: "40px",
    height: "40px",
    borderRadius: "12px",
    background: "linear-gradient(135deg,#a78bfa,#f472b6)",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    fontWeight: "700",
    fontSize: "1rem",
    color: "#fff",
    boxShadow: "0 10px 30px rgba(0,0,0,0.25)",
    zIndex: 2
  },

  difficultyBadge: {
    position: "absolute",
    top: "18px",
    right: "18px",
    padding: "6px 14px",
    borderRadius: "20px",
    fontSize: "0.7rem",
    fontWeight: "700",
    letterSpacing: "1px",
    backdropFilter: "blur(10px)"
  },

  easyBadge: {
    background: "rgba(34,197,94,0.15)",
    color: "#22c55e",
    border: "1px solid #22c55e"
  },

  mediumBadge: {
    background: "rgba(250,204,21,0.15)",
    color: "#facc15",
    border: "1px solid #facc15"
  },

  hardBadge: {
    background: "rgba(239,68,68,0.15)",
    color: "#ef4444",
    border: "1px solid #ef4444"
  }
};