import React, { useEffect, useState, useMemo } from "react";
import DashboardLayout from "../../components/layout/DashboardLayout";
import Sidebar from "../../components/layout/Sidebar";
import BackButton from "../../components/BackButton";
import Toast from "../../components/Toast";
import { theme } from "../../styles/theme";

// charts
import { Bar, Pie } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  ArcElement,
  Tooltip,
  Legend
} from 'chart.js';
import ChartDataLabels from 'chartjs-plugin-datalabels';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  ArcElement,
  Tooltip,
  Legend,
  ChartDataLabels
);

export default function QuizAnalytics({ username, role, onDashboard, onCreateQuiz, onAttemptQuiz, onViewAttempts, onMyQuizzes, onLogout }) {
  const [quizzes, setQuizzes] = useState([]);
  const [attempts, setAttempts] = useState([]);
  const [selectedQuiz, setSelectedQuiz] = useState(null);
  const [selectedAttempt, setSelectedAttempt] = useState(null);
  const [hoveredCard, setHoveredCard] = useState(null);
  const [hoveredAttempt, setHoveredAttempt] = useState(null);
  const [flash, setFlash] = useState(null);

  const formatImage = (img) => {
    if (!img) return null;
    if (img.startsWith("http")) return img;
    const clean = img.startsWith("/") ? img : `/${img}`;
    return `http://localhost:5000${clean}`;
  };

  const getQuestionType = (q) => {
    if (!q) return "mcq";
    if (q.type) return q.type;
    if (q.correctIndex !== undefined) return "mcq";
    if (Array.isArray(q.correctAnswers)) {
      if (q.correctAnswers.length > 1) return "msq";
      return "mcq";
    }
    return "mcq";
  };

  const computeScoreClient = (attempt) => {
    if (!attempt || !attempt.questions) return { score: 0, total: 0 };
    let score = 0;
    let total = 0;
    attempt.questions.forEach((q, i) => {
      const type = getQuestionType(q);
      const qMarks = Number(q.marks || 1);
      total += qMarks;

      const userAnswer = attempt.answers?.[i];

      if (type === "text") {
        if (attempt.manualMarks && Object.prototype.hasOwnProperty.call(attempt.manualMarks, i)) {
          score += Number(attempt.manualMarks[i]) || 0;
        }
        return;
      }

      if (type === "mcq" || type === "image") {
        const correctIndex = q.correctIndex !== undefined ? q.correctIndex : q.correctAnswers?.[0];
        if (userAnswer === correctIndex) score += qMarks;
        return;
      }

      if (type === "msq") {
        const correctAnswers = q.correctAnswers || [];
        if (Array.isArray(userAnswer) && correctAnswers.length === userAnswer.length && correctAnswers.every(idx => userAnswer.includes(idx))) {
          score += qMarks;
        }
        return;
      }
    });

    return { score, total };
  };

  useEffect(() => {
    fetch("http://localhost:5000/quizzes")
      .then((r) => r.json())
      .then((data) => setQuizzes(data || []))
      .catch(() => setQuizzes([]));

    fetch("http://localhost:5000/attempts")
      .then((r) => r.json())
      .then((data) => setAttempts(data || []))
      .catch(() => setAttempts([]));
  }, []);

  useEffect(() => {
    let socket;
    try {
      socket = new WebSocket('ws://localhost:5000');
    } catch (e) {
      socket = null;
    }

    if (socket) {
      socket.addEventListener('message', (ev) => {
        try {
          const msg = JSON.parse(ev.data);
          if (msg.event === 'attempt.updated') {
            const updated = msg.data;
            if (!updated) return;
            setAttempts(prev => {
              const found = prev.some(a => a.id === updated.id);
              if (found) return prev.map(a => (a.id === updated.id ? updated : a));
              return [updated, ...prev];
            });
            if (selectedAttempt && selectedAttempt.id === updated.id) {
              setSelectedAttempt(updated);
            }
          }
        } catch (err) {}
      });
    }

    return () => { try { socket && socket.close(); } catch(e) {} };
  }, [selectedAttempt]);

  const handleApplyMark = async (attemptId, qi, marks) => {
    setFlash('Applying...');

    // optimistic update
    setAttempts(prev => prev.map(a => (a.id === attemptId ? { ...a, manualMarks: { ...(a.manualMarks || {}), [qi]: marks }, ...computeScoreClient({ ...a, manualMarks: { ...(a.manualMarks || {}), [qi]: marks } }) } : a)));

    try {
      const res = await fetch(`http://localhost:5000/attempts/${attemptId}/question/${qi}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ marks })
      });

      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        setFlash(err.message || 'Failed to save marks');
        return;
      }

      const updated = await res.json();
      setSelectedAttempt(updated);
      setAttempts(prev => prev.map(a => (a.id === updated.id ? updated : a)));
      setFlash('Marks saved');
      setTimeout(() => setFlash(null), 1400);
    } catch (err) {
      console.error('Apply failed', err);
      setFlash('Failed to save marks');
    }
  };

  // chart data hooks
  const studentBarData = useMemo(() => {
    if (!selectedAttempt) return null;
    const labels = selectedAttempt.questions.map((_, idx) => `Q${idx + 1}`);
    const data = selectedAttempt.questions.map((q, i) => {
      const { score } = computeScoreClient({ questions: [q], answers: [(selectedAttempt.answers || [])[i]] });
      return score;
    });
    return {
      labels,
      datasets: [
        {
          label: 'Marks obtained',
          data,
          backgroundColor: (ctx) => {
            const chart = ctx.chart;
            const {ctx: canvasCtx, chartArea} = chart;
            if (!chartArea) return null;
            const gradient = canvasCtx.createLinearGradient(0, chartArea.bottom, 0, chartArea.top);
            gradient.addColorStop(0, 'rgba(59,130,246,0.6)');
            gradient.addColorStop(1, 'rgba(74,222,128,0.6)');
            return gradient;
          },
          hoverBackgroundColor: (ctx) => {
            const chart = ctx.chart;
            const {ctx: canvasCtx, chartArea} = chart;
            if (!chartArea) return null;
            const gradient = canvasCtx.createLinearGradient(0, chartArea.bottom, 0, chartArea.top);
            gradient.addColorStop(0, 'rgba(59,130,246,0.9)');
            gradient.addColorStop(1, 'rgba(74,222,128,0.9)');
            return gradient;
          },
          borderRadius: 4,
          barPercentage: 0.7
        }
      ]
    };
  }, [selectedAttempt]);

  const studentPieData = useMemo(() => {
    if (!selectedAttempt) return null;
    const correct = selectedAttempt.questions.reduce((acc, q, i) => {
      const { score } = computeScoreClient({ questions: [q], answers: [(selectedAttempt.answers || [])[i]] });
      return acc + (score > 0 ? 1 : 0);
    }, 0);
    const wrong = (selectedAttempt.questions.length || 0) - correct;
    return {
      labels: ['Correct', 'Wrong'],
      datasets: [
        {
          data: [correct, wrong],
          backgroundColor: ['#34d399', '#ef4444'],
          hoverOffset: 10
        }
      ]
    };
  }, [selectedAttempt]);

  const averagePieData = useMemo(() => {
    if (!selectedQuiz) return null;
    const quizAttempts = attempts.filter(
      a => a.quizId === selectedQuiz.id || a.quizTitle === selectedQuiz.title
    );
    const totalAttempts = quizAttempts.length;
    if (totalAttempts === 0) return null;
    const sum = quizAttempts.reduce((s, a) => s + (Number(a.score) || 0), 0);
    const avg = sum / totalAttempts;
    const maxTotal = selectedQuiz.questions
      ? selectedQuiz.questions.reduce((s, q) => s + Number(q.marks || 1), 0)
      : 0;
    const remainder = Math.max(0, maxTotal - avg);
    return {
      labels: ['Average score', 'Remaining'],
      datasets: [
        {
          data: [avg, remainder],
          backgroundColor: ['#6366f1', '#a1a1aa'],
          hoverOffset: 8
        }
      ]
    };
  }, [selectedQuiz, attempts]);

  return (
    <DashboardLayout
      sidebar={<Sidebar username={username} role={role || "creator"} onDashboard={onDashboard} onCreateQuiz={onCreateQuiz} onAttemptQuiz={onAttemptQuiz} onViewAttempts={onViewAttempts} onMyQuizzes={onMyQuizzes} onLogout={onLogout} />}
    >
      {flash && <Toast message={flash} onClose={() => setFlash(null)} />}
      <BackButton onClick={() => onDashboard ? onDashboard() : window.history.back()} />

      <h2 style={styles.title}>Quiz Analytics</h2>

      <div style={styles.grid}>
        {quizzes.map((quiz) => {
          const quizAttempts = attempts.filter(a => a.quizId === quiz.id || a.quizTitle === quiz.title);
          const totalAttempts = quizAttempts.length;
          const avg = totalAttempts > 0 ? (quizAttempts.reduce((sum, a) => sum + (Number(a.score) || 0), 0) / totalAttempts).toFixed(2) : '0.00';
          const uniqueUsers = [...new Set(quizAttempts.map(a => a.username))];

          return (
            <div
              key={quiz.id}
              style={{ ...styles.analyticsCard, ...(hoveredCard === quiz.id && styles.cardHover) }}
              onMouseEnter={() => setHoveredCard(quiz.id)}
              onMouseLeave={() => setHoveredCard(null)}
              onClick={() => { setSelectedQuiz(quiz); setSelectedAttempt(null); }}
            >
              <h3 style={styles.quizTitle}>{quiz.title}</h3>

              <div style={styles.analyticsStats}>
                <div style={styles.statBox}>
                  <span style={styles.statNumberQuestions}>{quiz.questions?.length || 0}</span>
                  <span style={styles.statLabel}>Questions</span>
                </div>

                <div style={styles.statBox}>
                  <span style={styles.statNumberAttempts}>{totalAttempts}</span>
                  <span style={styles.statLabel}>Attempts</span>
                </div>

                <div style={styles.statBox}>
                  <span style={styles.statNumberAverage}>{avg}</span>
                  <span style={styles.statLabel}>Avg Score</span>
                </div>
              </div>

              {uniqueUsers.length > 0 && (
                <div style={styles.userSection}>
                  <span style={styles.userLabel}>Users:</span>
                  <div style={styles.userList}>
                    {uniqueUsers.map((u, i) => (
                      <span key={i} style={styles.userBadge}>{u}</span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {selectedQuiz && (
        <div style={{ marginTop: 20 }}>
          <h3 style={{ marginBottom: 12 }}>Attempts for: {selectedQuiz.title}</h3>

          {/* class average pie chart */}
          {averagePieData && (
            <div style={{ width: 300, margin: '12px 0' }}>
              <Pie data={averagePieData} options={{
                plugins: { 
                  legend: { position: 'bottom', labels: { color: 'white' } },
                  datalabels: {
                    color: 'white',
                    formatter: (value, ctx) => {
                      const sum = ctx.dataset.data.reduce((a,b) => a + b, 0);
                      const pct = sum ? ((value/sum)*100).toFixed(1)+'%' : '';
                      return pct;
                    }
                  }
                },
                animation: { duration: 600, easing: 'easeOutQuart' }
              }} />
              <p style={{ textAlign: 'center', fontSize: '0.9rem', opacity: 0.8 }}>Average vs total</p>
            </div>
          )}

          {attempts.filter(a => a.quizId === selectedQuiz.id || a.quizTitle === selectedQuiz.title).map((attempt, index) => (
            <div key={index} style={styles.attemptCard} onClick={() => setSelectedAttempt(attempt)} onMouseEnter={() => setHoveredAttempt(index)} onMouseLeave={() => setHoveredAttempt(null)}>
              <div>
                <h4 style={styles.attemptUser}>{attempt.username}</h4>
                <p style={styles.time}>{new Date(attempt.timestamp).toLocaleString()}</p>
              </div>
              <div style={styles.attemptScore}>{attempt.score}/{attempt.total}</div>
            </div>
          ))}
        </div>
      )}

      {selectedAttempt && (
        <div style={{ marginTop: 18 }}>
          <h3 style={styles.title}>{selectedAttempt.username}'s Attempt</h3>

          {/* student charts */}
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 32, marginBottom: 24 }}>
            {studentBarData && (
              <div style={{ width: 320 }}>
                <Bar data={studentBarData} options={{
                  responsive: true,
                  scales: {
                    x: {
                      title: { display: true, text: 'Question Number', color: 'white' },
                      ticks: { color: 'white' }
                    },
                    y: {
                      beginAtZero: true,
                      title: { display: true, text: 'Marks', color: 'white' },
                      ticks: { stepSize: 1, color: 'white' }
                    }
                  },
                  plugins: { 
                    legend: { display: false },
                    datalabels: {
                      color: 'white',
                      anchor: 'end',
                      align: 'start',
                      font: { weight: 'bold' },
                      formatter: (value) => value
                    }
                  },
                  animation: { duration: 500, easing: 'easeOutQuad' },
                  hover: { mode: 'nearest' }
                }} />
              </div>
            )}
            {studentPieData && (
              <div style={{ width: 320 }}>
                <Pie data={studentPieData} options={{
                  plugins: { 
                    legend: { position: 'bottom', labels: { color: 'white' } },
                    datalabels: {
                      color: 'white',
                      formatter: (value, ctx) => {
                        const sum = ctx.dataset.data.reduce((a,b) => a + b, 0);
                        const pct = sum ? ((value/sum)*100).toFixed(1)+'%' : '';
                        return pct;
                      }
                    }
                  },
                  animation: { duration: 500, easing: 'easeOutQuad' }
                }} />
              </div>
            )}
          </div>

          {selectedAttempt.questions.map((q, qi) => {
            const type = getQuestionType(q);
            const userAnswer = selectedAttempt.answers?.[qi];

            return (
              <div key={qi} style={styles.detailCard}>
                <p style={styles.questionText}>{qi + 1}. {q.text}</p>
                {q.image && <img src={formatImage(q.image)} alt="Question" style={styles.analyticsQuestionImage} />}

                {type === 'text' && (
                  <div>
                    <p>User Answer: {userAnswer || 'Not answered'}</p>

                    {selectedAttempt.manualMarks?.[qi] !== undefined && (
                      <p style={Number(selectedAttempt.manualMarks[qi]) > 0 ? styles.correct : styles.wrong}>Marked: {selectedAttempt.manualMarks[qi]}/{q.marks || 1}</p>
                    )}

                    <div style={{ display: 'flex', gap: 10, alignItems: 'center', marginTop: 8 }}>
                      <input type="range" min={0} max={q.marks || 1} step={0.1} value={selectedAttempt.manualMarks?.[qi] ?? (q.marks || 1)} onChange={(e) => {
                        const v = Number(e.target.value);
                        setSelectedAttempt(prev => ({ ...prev, manualMarks: { ...(prev.manualMarks || {}), [qi]: v } }));
                      }} style={styles.range} />

                      <div style={{ minWidth: 72, textAlign: 'center', color: '#c4b5fd', fontWeight: 700 }}>{(selectedAttempt.manualMarks?.[qi] ?? (q.marks || 1)).toFixed(1)} / {(q.marks || 1).toFixed ? (q.marks || 1).toFixed(1) : q.marks}</div>

                      <button style={styles.applyBtn} onClick={() => handleApplyMark(selectedAttempt.id, qi, Number(selectedAttempt.manualMarks?.[qi] ?? (q.marks || 1)))}>Apply</button>
                    </div>
                  </div>
                )}

                {(type === 'mcq' || type === 'image') && (() => {
                  const correctIndex = q.correctIndex !== undefined ? q.correctIndex : q.correctAnswers?.[0];
                  const userOption = typeof userAnswer === 'number' ? q.options?.[userAnswer] : null;
                  const correctOption = typeof correctIndex === 'number' ? q.options?.[correctIndex] : null;

                  if (type === 'image') {
                    const isCorrect = userAnswer === correctIndex;
                    return (
                      <>
                        {isCorrect ? (
                          <>
                            <p style={styles.correct}>User Answer:</p>
                            {userOption?.image && <img src={formatImage(userOption.image)} alt="User Option" style={styles.analyticsOptionImage} />}
                          </>
                        ) : (
                          <>
                            <p style={styles.wrong}>User Answer:</p>
                            {userOption?.image && <img src={formatImage(userOption.image)} alt="User Option" style={styles.analyticsOptionImage} />}
                            <p style={styles.correct}>Correct Answer:</p>
                            {correctOption?.image && <img src={formatImage(correctOption.image)} alt="Correct Option" style={styles.analyticsOptionImage} />}
                          </>
                        )}
                      </>
                    );
                  }

                  const isCorrect = userAnswer === correctIndex;
                  const userText = userOption?.text || '';
                  const correctText = correctOption?.text || '';
                  return isCorrect ? <p style={styles.correct}>User Answer: {userText}</p> : (<><p style={styles.wrong}>User Answer: {userText}</p><p style={styles.correct}>Correct Answer: {correctText}</p></>);
                })()}

                {type === 'msq' && (() => {
                  const correctAnswers = q.correctAnswers || [];
                  const userArray = selectedAttempt.answers?.[qi] || [];
                  const isCorrect = Array.isArray(userArray) && correctAnswers.length === userArray.length && correctAnswers.every(idx => userArray.includes(idx));
                  const userText = Array.isArray(userArray) ? userArray.map(idx => q.options?.[idx]?.text || '').join(', ') : 'Not answered';
                  const correctText = correctAnswers.map(idx => q.options?.[idx]?.text || '').join(', ');
                  return isCorrect ? <p style={styles.correct}>User Answer: {userText}</p> : (<><p style={styles.wrong}>User Answer: {userText}</p><p style={styles.correct}>Correct Answer: {correctText}</p></>);
                })()}

              </div>
            );
          })}
        </div>
      )}
    </DashboardLayout>
  );
}

const styles = {
  title: {
    marginBottom: theme.spacing.lg,
    fontSize: "1.8rem"
  },

  grid: {
    display: "grid",
    gridTemplateColumns:
      "repeat(auto-fill,minmax(320px,1fr))",
    gap: "28px"
  },

  analyticsCard: {
    padding: "24px",
    borderRadius: "20px",
    background:
      "rgba(255,255,255,0.08)",
    backdropFilter: "blur(18px)",
    border:
      "1px solid rgba(255,255,255,0.15)",
    boxShadow:
      "0 20px 50px rgba(0,0,0,0.3)",
    cursor: "pointer",
    transition: "all 0.3s ease"
  },

  attemptCard: {
    padding: "16px",
    borderRadius: "16px",
    background:
      "rgba(255,255,255,0.06)",
    display: "flex",
    justifyContent: "space-between",
    marginBottom: "14px",
    cursor: "pointer",
    transition: "all 0.3s ease"
  },
analyticsQuestionImage: {
  width: "160px",
  maxHeight: "110px",
  objectFit: "contain",
  borderRadius: "10px",
  marginBottom: "10px",
  display: "block"
},

analyticsOptionImage: {
  width: "120px",
  maxHeight: "90px",
  objectFit: "contain",
  borderRadius: "8px",
  marginBottom: "6px",
  display: "block"
},
  cardHover: {
    transform: "translateY(-6px)",
    boxShadow:
      "0 28px 70px rgba(0,0,0,0.45)"
  },

  backBtn: {
    marginBottom: "16px",
    padding: "8px 14px",
    borderRadius: "10px",
    border:
      "1px solid rgba(255,255,255,0.25)",
    background:
      "rgba(255,255,255,0.08)",
    cursor: "pointer",
    transition: "all 0.25s ease"
  },

  backHover: {
    transform: "translateY(-4px)",
    boxShadow:
      "0 12px 30px rgba(0,0,0,0.35)"
  },

  /* rest unchanged */

  analyticsStats: {
    display: "flex",
    justifyContent: "space-between",
    marginTop: "14px"
  },

  statBox: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center"
  },

statNumberQuestions: {
  fontSize: "1.6rem",
  fontWeight: 800,
    background: "linear-gradient(135deg, #c8f141d4, #16d9e7e3)",
  WebkitBackgroundClip: "text",
  WebkitTextFillColor: "transparent",
  backgroundClip: "text"
},

statNumberAttempts: {
  fontSize: "1.6rem",
  fontWeight: 800,
  background: "linear-gradient(135deg, #cb4141, #0a0a09)",
  WebkitBackgroundClip: "text",
  WebkitTextFillColor: "transparent",
  backgroundClip: "text"
},

statNumberAverage: {
  fontSize: "1.6rem",
  fontWeight: 800,
  background: "linear-gradient(135deg, #c7cd27, #10c121)",
  WebkitBackgroundClip: "text",
  WebkitTextFillColor: "transparent",
  backgroundClip: "text"
},


  statLabel: {
    fontSize: "0.75rem",
    opacity: 0.7
  },

  userPreview: {
    marginTop: "12px",
    display: "flex",
    flexWrap: "wrap",
    gap: "8px"
  },

userSection: {
  marginTop: "14px",
  display: "flex",
  flexDirection: "column",
  gap: "8px"
},

userLabel: {
  fontSize: "0.8rem",
  opacity: 0.7,
  fontWeight: 500
},

userList: {
  display: "flex",
  flexWrap: "wrap",       // 🔥 allows wrapping automatically
  gap: "8px",
  maxWidth: "100%"        // prevents overflow outside card
},

userBadge: {
  padding: "6px 12px",
  borderRadius: "14px",
  background: "rgba(228, 228, 230, 0.15)",
  border: "1px solid rgba(250, 139, 161, 0.35)",
  color: "#070707",
  fontSize: "0.75rem",
  fontWeight: 500,
  whiteSpace: "nowrap"
},

answerLabel: {
  fontWeight: 600,
  marginTop: "8px",
  marginBottom: "6px",
  color: "#c4b5fd"
},
  moreUsers: {
    fontSize: "0.75rem",
    opacity: 0.7
  },

  summaryRow: {
    display: "flex",
    gap: "20px",
    marginBottom: "20px"
  },

  summaryCard: {
    padding: "16px",
    borderRadius: "16px",
    background:
      "rgba(255,255,255,0.08)"
  },

  attemptUser: {
    fontWeight: 600
  },

  attemptScore: {
    fontWeight: 700,
    color: "#34d399"
  },
difficultyBadge: {
  display: "inline-block",
  padding: "8px 16px",
  borderRadius: "20px",
  fontWeight: 600,
  marginBottom: "20px",
  fontSize: "0.9rem"
},

easyBadge: {
  background: "linear-gradient(135deg,#22c55e,#16a34a)",
  color: "white"
},

mediumBadge: {
  background: "linear-gradient(135deg,#facc15,#f97316)",
  color: "black"
},

hardBadge: {
  background: "linear-gradient(135deg,#ef4444,#b91c1c)",
  color: "white"
},
  detailCard: {
    padding: "16px",
    borderRadius: "16px",
    background:
      "rgba(255,255,255,0.06)",
    marginBottom: "14px"
  },

  questionText: {
    marginBottom: "8px"
  },

  correct: {
    color: "#34d399",
    fontWeight: 600,
    textShadow: "0 0 4px rgba(52, 211, 153, 0.6)"
  },

  wrong: {
    color: "#a70808",
    fontWeight: 600,
    textShadow: "0 0 4px rgba(167, 8, 8, 0.6)"
  },

  scoreHighlight: {
    fontSize: "1.2rem",
    marginBottom: "20px",
    color: "#c4b5fd"
  },

  time: {
    fontSize: "0.85rem",
    opacity: 0.8,
    color: "#000000"
  }
};

// Add button styles at the bottom so they blend with existing theme
styles.correctBtn = {
  padding: "8px 12px",
  borderRadius: "8px",
  background: "linear-gradient(90deg,#10b981,#34d399)",
  color: "white",
  border: "none",
  cursor: "pointer",
  fontWeight: 700
};

styles.wrongBtn = {
  padding: "8px 12px",
  borderRadius: "8px",
  background: "linear-gradient(90deg,#ef4444,#f97316)",
  color: "white",
  border: "none",
  cursor: "pointer",
  fontWeight: 700
};

styles.range = {
  width: "280px",
  accentColor: "#67e8f9",
  height: "6px"
};

styles.applyBtn = {
  padding: "8px 12px",
  borderRadius: "8px",
  background: "#67e8f9",
  color: "#051019",
  border: "none",
  cursor: "pointer",
  fontWeight: 700
};

// flash replaced by Toast component
