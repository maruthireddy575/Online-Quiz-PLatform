import React, { useState, useEffect } from "react";
import DashboardLayout from "../../components/layout/DashboardLayout";
import Sidebar from "../../components/layout/Sidebar";
import BackButton from "../../components/BackButton";

export default function CreateQuiz({
  username,
  onDashboard,
  onCreateQuiz,
  onViewAttempts,
  onLogout,
  onBack,
  editingQuizId
}) {
  const role = "creator";

  const [title, setTitle] = useState("");
  const [difficulty, setDifficulty] = useState("medium");
  const [questions, setQuestions] = useState([
    createNewQuestion()
  ]);
  const [timeLimit, setTimeLimit] = useState(0);

  const isEditMode = !!editingQuizId;

  function createNewQuestion() {
    return {
      type: "mcq",
      text: "",
      imageFile: null,
      explanation: "", // 🔥 EXPLANATION FIELD
      options: ["", ""],
      optionImages: [],
      correctAnswers: []
    };
  }

  function transformQuestion(q) {
    const formatPath = (img) => {
      if (!img) return null;
      if (img.startsWith("http")) return img;
      const cleanPath = img.startsWith("/") ? img : `/${img}`;
      return `http://localhost:5000${cleanPath}`;
    };

    return {
      type: q.type || "mcq",
      text: q.text || "",
      imageFile: formatPath(q.image),
      explanation: q.explanation || "", // 🔥 LOAD EXPLANATION
      options: (q.options || []).map(opt =>
        typeof opt === "string" ? opt : opt.text || ""
      ),
      optionImages: (q.options || []).map(opt =>
        formatPath(opt.image)
      ),
      correctAnswers: q.correctAnswers || []
    };
  }

  useEffect(() => {
    if (!editingQuizId) return;

    fetch(`http://localhost:5000/quizzes/${editingQuizId}`)
      .then(res => res.json())
      .then(data => {
        setTitle(data.title || "");
        setDifficulty(data.difficulty || "medium");
        setQuestions(
          data.questions
            ? data.questions.map(transformQuestion)
            : [createNewQuestion()]
        );
        setTimeLimit(data.timeLimit || 0);
      })
      .catch(() => alert("Failed to load quiz"));
  }, [editingQuizId]);

  const updateQuestion = (index, field, value) => {
    const copy = [...questions];
    copy[index][field] = value;
    setQuestions(copy);
  };

  const updateOption = (qi, oi, value) => {
    const copy = [...questions];
    copy[qi].options[oi] = value;
    setQuestions(copy);
  };

  const toggleCorrectAnswer = (qi, oi) => {
    const copy = [...questions];

    if (copy[qi].type === "mcq" || copy[qi].type === "image") {
      copy[qi].correctAnswers = [oi];
    } else {
      const correct = copy[qi].correctAnswers;
      if (correct.includes(oi)) {
        copy[qi].correctAnswers = correct.filter(i => i !== oi);
      } else {
        copy[qi].correctAnswers.push(oi);
      }
    }

    setQuestions(copy);
  };

  const addOption = (qi) => {
    const copy = [...questions];
    copy[qi].options.push("");
    setQuestions(copy);
  };

  const removeOption = (qi, oi) => {
    const copy = [...questions];
    copy[qi].options.splice(oi, 1);
    copy[qi].correctAnswers =
      copy[qi].correctAnswers.filter(i => i !== oi);
    setQuestions(copy);
  };

  const deleteQuestion = (qi) => {
    const copy = [...questions];
    copy.splice(qi, 1);
    setQuestions(copy.length ? copy : [createNewQuestion()]);
  };

  const addQuestion = () => {
    setQuestions([...questions, createNewQuestion()]);
  };

  const handleImageUpload = (file, callback) => {
    if (!file) return;
    const reader = new FileReader();
    reader.onloadend = () => callback(reader.result);
    reader.readAsDataURL(file);
  };

  // 🔥 UPDATED HANDLESAVE WITH DEBUG CODE
  const handleSave = async () => {
    if (!title.trim()) return alert("Quiz title required");

    // 🔥 DEBUG: Log what we're about to save
    console.log("=== SAVING QUIZ ===");
    console.log("Quiz Title:", title);
    console.log("Questions with explanations:", questions.map((q, index) => ({
      questionNumber: index + 1,
      text: q.text,
      explanation: q.explanation,
      options: q.options,
      correctAnswers: q.correctAnswers
    })));

    try {
      const url = isEditMode
        ? `http://localhost:5000/quizzes/${editingQuizId}`
        : "http://localhost:5000/quizzes";

      const method = isEditMode ? "PUT" : "POST";

      // 🔥 DEBUG: Log the request body
      const requestBody = {
        title,
        difficulty,
        questions,
        createdBy: username,
        timeLimit: Number(timeLimit) > 0 ? Number(timeLimit) : undefined
      };
      console.log("Request body:", JSON.stringify(requestBody, null, 2));

      const response = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(requestBody)
      });

      const data = await response.json();
      console.log("Server response:", data); // 🔥 See what server returns

      setTitle("");
      setDifficulty("medium");
      setQuestions([createNewQuestion()]);
      setTimeLimit(0);
      onBack();
    } catch (error) {
      console.error("Save failed:", error); // 🔥 Catch any errors
      alert("Failed to save quiz");
    }
  };

  return (
    <DashboardLayout
      sidebar={
        <Sidebar
          username={username}
          role={role}
          onDashboard={onDashboard}
          onCreateQuiz={onCreateQuiz}
          onViewAttempts={onViewAttempts}
          onLogout={onLogout}
        />
      }
    >
      <BackButton onClick={onBack} />
      <h2 style={styles.heading}>
        {isEditMode ? "Edit Quiz" : "Create Quiz"}
      </h2>

      <input
        style={styles.titleInput}
        placeholder="Quiz Title"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
      />

      {/* TIME LIMIT FIELD */}
      <div style={{ margin: "18px 0 10px 0" }}>
        <label style={{ fontWeight: 600, marginRight: 10, color: "white" }}>Time Limit (seconds, 0 = no limit):</label>
        <input
          type="number"
          min="0"
          value={timeLimit}
          onChange={e => setTimeLimit(e.target.value)}
          style={{ width: 120, padding: 6, borderRadius: 6, border: "1px solid #ccc" }}
        />
      </div>

      {/* DIFFICULTY SELECTOR */}
      <div style={styles.difficultyWrapper}>
        <span style={styles.difficultyLabel}>Choose Difficulty</span>
        <div style={styles.difficultyOptions}>
          {["easy", "medium", "hard"].map(level => (
            <div
              key={level}
              style={{
                ...styles.difficultyOption,
                ...(difficulty === level ? styles.difficultySelected : {})
              }}
              onClick={() => setDifficulty(level)}
            >
              {level.charAt(0).toUpperCase() + level.slice(1)}
            </div>
          ))}
        </div>
      </div>

      {/* QUESTIONS */}
      {questions.map((q, qi) => (
        <div key={qi} style={styles.card}>
          <div style={styles.cardHeader}>
            <h4 style={styles.questionTitle}>Question {qi + 1}</h4>
            <select
              value={q.type}
              onChange={(e) => updateQuestion(qi, "type", e.target.value)}
              style={styles.select}
            >
              <option value="mcq">Multiple Choice (MCQ)</option>
              <option value="msq">Multiple Select (MSQ)</option>
              <option value="text">Text Answer</option>
              <option value="image">Image Based</option>
            </select>
          </div>

          <input
            style={styles.input}
            placeholder="Enter question text"
            value={q.text}
            onChange={(e) => updateQuestion(qi, "text", e.target.value)}
          />

          {q.type === "image" && (
            <div style={styles.imageWrapper}>
              <label style={styles.imageUploadBox}>
                {q.imageFile ? (
                  <img src={q.imageFile} alt="Preview" style={styles.imagePreview} />
                ) : (
                  <span style={styles.imageUploadText}>Click to upload image</span>
                )}
                <input
                  type="file"
                  accept="image/*"
                  style={{ display: "none" }}
                  onChange={(e) =>
                    handleImageUpload(e.target.files[0], (base64) => {
                      const copy = [...questions];
                      copy[qi].imageFile = base64;
                      setQuestions(copy);
                    })
                  }
                />
              </label>
            </div>
          )}

          {/* OPTIONS */}
          {(q.type === "mcq" || q.type === "msq" || q.type === "image") &&
            q.options.map((opt, oi) => (
              <div
                key={oi}
                style={{
                  ...styles.optionRow,
                  ...(q.correctAnswers.includes(oi) ? styles.optionRowSelected : {})
                }}
              >
                <div style={styles.optionTopRow}>
                  <input
                    style={styles.optionInput}
                    placeholder={`Option ${oi + 1}`}
                    value={opt}
                    onChange={(e) => updateOption(qi, oi, e.target.value)}
                  />

                  <div
                    style={{
                      ...styles.correctSelector,
                      ...(q.correctAnswers.includes(oi) ? styles.correctSelected : {})
                    }}
                    onClick={() => toggleCorrectAnswer(qi, oi)}
                  >
                    {q.correctAnswers.includes(oi) && <div style={styles.correctDot} />}
                  </div>

                  {q.options.length > 2 && (
                    <button style={styles.removeBtn} onClick={() => removeOption(qi, oi)}>
                      ✕
                    </button>
                  )}
                </div>

                {q.type === "image" && q.optionImages?.[oi] && (
                  <img src={q.optionImages[oi]} alt="Option Preview" style={styles.smallOptionPreview} />
                )}

                {q.type === "image" && !q.optionImages?.[oi] && (
                  <label style={styles.smallUploadBox}>
                    <span style={styles.optionImageText}>Upload Image</span>
                    <input
                      type="file"
                      accept="image/*"
                      style={{ display: "none" }}
                      onChange={(e) =>
                        handleImageUpload(e.target.files[0], (base64) => {
                          const copy = [...questions];
                          if (!copy[qi].optionImages) copy[qi].optionImages = [];
                          copy[qi].optionImages[oi] = base64;
                          setQuestions(copy);
                        })
                      }
                    />
                  </label>
                )}
              </div>
            ))}

          {/* ADD OPTION & DELETE QUESTION BUTTONS */}
          {(q.type === "mcq" || q.type === "msq" || q.type === "image") && (
            <div style={styles.questionControls}>
              <button style={styles.addOptionBtn} onClick={() => addOption(qi)}>
                Add Option
              </button>
              <button style={styles.deleteQuestionBtn} onClick={() => deleteQuestion(qi)}>
                Delete Question
              </button>
            </div>
          )}

          {/* 🔥 EXPLANATION BOX - PLACED AFTER OPTIONS */}
          <div style={styles.explanationSection}>
            <label style={styles.explanationLabel}>
              Explanation (students will see this after attempting)
            </label>
            <textarea
              placeholder="Explain the correct answer, solution steps, or key concepts..."
              value={q.explanation || ""}
              onChange={(e) => updateQuestion(qi, "explanation", e.target.value)}
              style={styles.explanationInput}
              rows="4"
            />
          </div>
        </div>
      ))}

      <div style={styles.actions}>
        <button style={styles.secondary} onClick={addQuestion}>
          Add Question
        </button>
        <button style={styles.primary} onClick={handleSave}>
          {isEditMode ? "Update Quiz" : "Save Quiz"}
        </button>
      </div>
    </DashboardLayout>
  );
}

const styles = {
  heading: {
    marginBottom: "24px",
    fontSize: "1.9rem",
    fontWeight: "600",
    color: "white"
  },
  questionTitle: {
    color: "white",
    fontWeight: "600"
  },
  titleInput: {
    width: "100%",
    padding: "14px",
    borderRadius: "14px",
    border: "1px solid rgba(255,255,255,0.25)",
    background: "rgba(255,255,255,0.08)",
    color: "white",
    marginBottom: "30px"
  },
  card: {
    background: "rgba(255,255,255,0.08)",
    backdropFilter: "blur(18px)",
    border: "1px solid rgba(255,255,255,0.2)",
    borderRadius: "18px",
    padding: "20px",
    marginBottom: "24px",
    boxShadow: "0 15px 40px rgba(0,0,0,0.25)",
    color: "white"
  },
  cardHeader: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: "14px"
  },
  select: {
    padding: "8px 12px",
    borderRadius: "10px",
    backgroundColor: "#ffffff",
    color: "#111827",
    border: "1px solid rgba(255,255,255,0.3)",
    outline: "none",
    fontWeight: "500"
  },
  input: {
    width: "100%",
    padding: "12px",
    borderRadius: "12px",
    border: "1px solid rgba(255,255,255,0.25)",
    background: "rgba(255,255,255,0.12)",
    color: "white",
    marginBottom: "12px"
  },
  
  // 🔥 EXPLANATION BOX STYLES
  explanationSection: {
    marginTop: "20px",
    marginBottom: "10px",
    padding: "16px",
    background: "rgba(59, 130, 246, 0.1)",
    borderRadius: "12px",
    border: "1px solid #3b82f6"
  },
  explanationLabel: {
    display: "block",
    marginBottom: "8px",
    color: "#3b82f6",
    fontWeight: "600",
    fontSize: "0.95rem"
  },
  explanationInput: {
    width: "100%",
    padding: "12px",
    borderRadius: "8px",
    border: "1px solid rgba(255,255,255,0.2)",
    background: "rgba(255,255,255,0.08)",
    color: "white",
    fontFamily: "inherit",
    fontSize: "0.95rem",
    resize: "vertical"
  },

  optionRow: {
    display: "flex",
    flexDirection: "column",
    gap: "8px",
    marginBottom: "12px",
    padding: "12px",
    borderRadius: "12px",
    transition: "all 0.2s ease",
    border: "1px solid transparent"
  },
  optionRowSelected: {
    border: "1px solid #1be461",
    background: "rgba(91, 51, 236, 0.15)",
    boxShadow: "0 0 15px rgba(30, 255, 0, 0.6)"
  },
  optionInput: {
    flex: 1,
    padding: "10px",
    borderRadius: "10px",
    border: "1px solid rgba(255,255,255,0.25)",
    background: "rgba(255,255,255,0.08)",
    color: "white"
  },
  optionTopRow: {
    display: "flex",
    alignItems: "center",
    gap: "12px",
    width: "100%"
  },
  difficultyWrapper: {
    marginBottom: "24px"
  },
  difficultyLabel: {
    display: "block",
    marginBottom: "10px",
    fontWeight: "600",
    opacity: 0.9,
    color: "white"
  },
  difficultyOptions: {
    display: "flex",
    gap: "12px"
  },
  difficultyOption: {
    padding: "8px 16px",
    borderRadius: "20px",
    border: "1px solid rgba(250, 139, 161, 0.35)",
    background: "rgba(228, 228, 230, 0.15)",
    color: "#070707",
    cursor: "pointer",
    transition: "all 0.2s ease",
    textTransform: "capitalize"
  },
  difficultySelected: {
    background: "linear-gradient(135deg, #7661b7, #d89235)",
    color: "white",
    boxShadow: "0 0 15px rgba(167,139,250,0.5)"
  },
  smallOptionPreview: {
    width: "160px",
    maxHeight: "120px",
    objectFit: "contain",
    borderRadius: "8px"
  },
  smallUploadBox: {
    width: "160px",
    height: "80px",
    borderRadius: "8px",
    border: "1px dashed rgba(255,255,255,0.4)",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    cursor: "pointer",
    background: "rgba(255,255,255,0.05)"
  },
  imageWrapper: {
    marginBottom: "16px",
    display: "flex",
    justifyContent: "center"
  },
  imagePreview: {
    maxWidth: "220px",
    maxHeight: "140px",
    objectFit: "contain",
    borderRadius: "10px",
    display: "block",
    margin: "0 auto"
  },
  optionImageUpload: {
    width: "55px",
    height: "55px",
    borderRadius: "10px",
    border: "1px dashed rgba(255,255,255,0.4)",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    cursor: "pointer",
    overflow: "hidden",
    background: "rgba(255,255,255,0.06)"
  },
  optionImagePreview: {
    width: "100%",
    height: "100%",
    objectFit: "cover"
  },
  optionImageText: {
    fontSize: "18px",
    opacity: 0.7
  },
  removeBtn: {
    background: "transparent",
    border: "none",
    color: "#f87171",
    cursor: "pointer",
    fontSize: "16px"
  },
  textNote: {
    fontSize: "0.9rem",
    color: "rgba(255,255,255,0.8)"
  },
  actions: {
    display: "flex",
    gap: "16px",
    marginTop: "30px"
  },
  primary: {
    padding: "12px 20px",
    borderRadius: "14px",
    border: "none",
    background: "linear-gradient(135deg, #a78bfa, #f472b6)",
    color: "#fff",
    cursor: "pointer",
    boxShadow: "0 10px 30px rgba(0,0,0,0.25)"
  },
  secondary: {
    padding: "12px 20px",
    borderRadius: "14px",
    border: "1px solid rgba(255,255,255,0.25)",
    background: "rgba(255,255,255,0.08)",
    color: "white",
    cursor: "pointer"
  },
  correctSelector: {
    width: "22px",
    height: "22px",
    borderRadius: "50%",
    border: "2px solid rgba(255,255,255,0.4)",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    cursor: "pointer",
    transition: "all 0.2s ease"
  },
  correctSelected: {
    border: "2px solid #ea1f0491",
    boxShadow: "0 0 12px rgba(12, 220, 43, 0.6)"
  },
  correctDot: {
    width: "10px",
    height: "10px",
    borderRadius: "50%",
    background: "linear-gradient(135deg,#a78bfa,#f472b6)"
  },
  imageUploadBox: {
    border: "2px dashed rgba(255,255,255,0.3)",
    borderRadius: "14px",
    padding: "20px",
    textAlign: "center",
    cursor: "pointer",
    background: "rgba(255,255,255,0.05)",
    transition: "all 0.2s ease",
    marginBottom: "12px"
  },
  imageUploadText: {
    opacity: 0.7
  },
  questionControls: {
    display: "flex",
    gap: "12px",
    marginTop: "10px"
  },
  addOptionBtn: {
    marginTop: "8px",
    padding: "8px 12px",
    borderRadius: "10px",
    border: "1px solid rgba(9, 199, 113, 0.81)",
    background: "rgba(14, 148, 43, 0.5)",
    color: "#000000",
    cursor: "pointer"
  },
  deleteQuestionBtn: {
    marginTop: "8px",
    padding: "8px 12px",
    borderRadius: "10px",
    border: "1px solid rgba(248,113,113,0.5)",
    background: "rgba(248,113,113,0.15)",
    color: "#000000",
    cursor: "pointer"
  }
};