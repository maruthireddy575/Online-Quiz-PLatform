import React from "react";
import DashboardLayout from "../components/layout/DashboardLayout";
import Sidebar from "../components/layout/Sidebar";

export default function TestMultiColor({ username }) {
  return (
    <DashboardLayout
      sidebar={
        <Sidebar
          username={username}
          role="attempter"
          onDashboard={() => console.log("Dashboard")}
          onAttemptQuiz={() => console.log("Attempt Quiz")}
          onViewAttempts={() => console.log("View Attempts")}
          onLogout={() => console.log("Logout")}
        />
      }
    >
      <div className="animate-slide-in">
        <h1 style={{ 
          fontSize: "var(--font-size-3xl)", 
          fontWeight: "700", 
          color: "var(--text-primary)",
          marginBottom: "var(--spacing-4)"
        }}>
          🎨 Multi-Color Theme Test
        </h1>
        
        <p style={{ 
          color: "var(--text-secondary)", 
          marginBottom: "var(--spacing-8)",
          fontSize: "var(--font-size-lg)"
        }}>
          Testing the new multi-color dashboard theme system with different colors for each section!
        </p>

        {/* Test All Card Colors */}
        <div style={{ marginBottom: "var(--spacing-8)" }}>
          <h2 style={{ 
            fontSize: "var(--font-size-2xl)", 
            fontWeight: "600", 
            color: "var(--text-primary)",
            marginBottom: "var(--spacing-6)"
          }}>
            🌈 Multi-Color Card System
          </h2>
          
          <div style={{ 
            display: "grid", 
            gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))", 
            gap: "var(--spacing-6)" 
          }}>
            <div className="card card-primary">
              <div className="card-header">
                <h3>Primary Card</h3>
              </div>
              <div className="card-body">
                <p>Blue border and header</p>
                <button className="btn btn-primary">Primary Button</button>
              </div>
            </div>

            <div className="card card-success">
              <div className="card-header">
                <h3>Success Card</h3>
              </div>
              <div className="card-body">
                <p>Green border and header</p>
                <button className="btn btn-success">Success Button</button>
              </div>
            </div>

            <div className="card card-warning">
              <div className="card-header">
                <h3>Warning Card</h3>
              </div>
              <div className="card-body">
                <p>Orange border and header</p>
                <button className="btn btn-warning">Warning Button</button>
              </div>
            </div>

            <div className="card card-danger">
              <div className="card-header">
                <h3>Danger Card</h3>
              </div>
              <div className="card-body">
                <p>Red border and header</p>
                <button className="btn btn-danger">Danger Button</button>
              </div>
            </div>

            <div className="card card-info">
              <div className="card-header">
                <h3>Info Card</h3>
              </div>
              <div className="card-body">
                <p>Cyan border and header</p>
                <button className="btn btn-outline">Outline Button</button>
              </div>
            </div>

            <div className="card card-purple">
              <div className="card-header">
                <h3>Purple Card</h3>
              </div>
              <div className="card-body">
                <p>Purple border and header</p>
                <button className="btn btn-secondary">Secondary Button</button>
              </div>
            </div>
          </div>
        </div>

        {/* Test Statistics Cards */}
        <div style={{ marginBottom: "var(--spacing-8)" }}>
          <h2 style={{ 
            fontSize: "var(--font-size-2xl)", 
            fontWeight: "600", 
            color: "var(--text-primary)",
            marginBottom: "var(--spacing-6)"
          }}>
            📊 Statistics Cards
          </h2>
          
          <div style={{ 
            display: "grid", 
            gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", 
            gap: "var(--spacing-6)" 
          }}>
            <div className="stat-card success">
              <div className="stat-value">1,234</div>
              <div className="stat-label">Success Metric</div>
              <div className="stat-change positive">+12.5%</div>
            </div>

            <div className="stat-card warning">
              <div className="stat-value">567</div>
              <div className="stat-label">Warning Metric</div>
              <div className="stat-change negative">-3.2%</div>
            </div>

            <div className="stat-card danger">
              <div className="stat-value">89</div>
              <div className="stat-label">Danger Metric</div>
              <div className="stat-change positive">+2 new</div>
            </div>

            <div className="stat-card info">
              <div className="stat-value">456</div>
              <div className="stat-label">Info Metric</div>
              <div className="stat-change positive">+8.7%</div>
            </div>
          </div>
        </div>

        {/* Test Visual Hierarchy */}
        <div style={{ marginBottom: "var(--spacing-8)" }}>
          <h2 style={{ 
            fontSize: "var(--font-size-2xl)", 
            fontWeight: "600", 
            color: "var(--text-primary)",
            marginBottom: "var(--spacing-6)"
          }}>
            🏗️ Visual Hierarchy
          </h2>
          
          <div className="container-large" style={{ marginBottom: "var(--spacing-6)" }}>
            <h3>Large Container</h3>
            <p>Subtle background with enhanced shadows for main sections.</p>
            <button className="btn btn-primary">Large Action</button>
          </div>

          <div style={{ 
            display: "grid", 
            gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))", 
            gap: "var(--spacing-6)",
            marginBottom: "var(--spacing-6)"
          }}>
            <div className="container-medium">
              <h4>Medium Container</h4>
              <p>White background with medium shadows for standard cards.</p>
              <button className="btn btn-secondary">Medium Action</button>
            </div>

            <div className="container-medium">
              <h4>Another Medium</h4>
              <p>Consistent styling across all medium containers.</p>
              <button className="btn btn-outline">Outline Action</button>
            </div>
          </div>

          <div style={{ 
            display: "grid", 
            gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", 
            gap: "var(--spacing-4)"
          }}>
            <div className="container-small">
              <h5>Small Container</h5>
              <p>Minimal styling for auxiliary information.</p>
              <span className="badge badge-info">Info</span>
            </div>

            <div className="container-small">
              <h5>Quick Info</h5>
              <p>Lightweight and subtle presentation.</p>
              <span className="badge badge-success">Success</span>
            </div>

            <div className="container-small">
              <h5>Status</h5>
              <p>Status indicators and badges.</p>
              <span className="badge badge-warning">Warning</span>
            </div>
          </div>
        </div>

        {/* Test Badges */}
        <div className="container-medium">
          <h2 style={{ 
            fontSize: "var(--font-size-2xl)", 
            fontWeight: "600", 
            color: "var(--text-primary)",
            marginBottom: "var(--spacing-4)"
          }}>
            🏷️ Status Badges
          </h2>
          <p style={{ color: "var(--text-secondary)", marginBottom: "var(--spacing-6)" }}>
            Different colored badges for various status indicators:
          </p>
          
          <div style={{ display: "flex", gap: "var(--spacing-3)", flexWrap: "wrap" }}>
            <span className="badge badge-success">Success</span>
            <span className="badge badge-warning">Warning</span>
            <span className="badge badge-danger">Danger</span>
            <span className="badge badge-info">Info</span>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
