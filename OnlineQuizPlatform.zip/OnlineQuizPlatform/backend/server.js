require("dotenv").config();

const http = require('http');
const app = require("./src/app");
const wsUtil = require("./src/utils/ws");

const PORT = process.env.PORT || 5000;

const server = http.createServer(app);

// initialize WebSocket server
wsUtil.init(server);

server.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
});
