const WebSocket = require('ws');
let wss = null;

function init(server) {
  if (wss) return wss;
  wss = new WebSocket.Server({ server });
  wss.on('connection', (socket) => {
    // keep connections alive; simple ping/pong handled by ws lib
    socket.on('message', () => {});
  });
  console.log('WebSocket server initialized');
  return wss;
}

function broadcast(event, data) {
  if (!wss) return;
  const message = JSON.stringify({ event, data });
  wss.clients.forEach((client) => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(message);
    }
  });
}

module.exports = {
  init,
  broadcast
};
