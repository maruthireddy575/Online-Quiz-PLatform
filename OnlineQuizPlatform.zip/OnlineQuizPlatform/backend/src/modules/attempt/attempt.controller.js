const service = require("./attempt.service");
const ws = require("../../utils/ws");

function saveAttempt(req, res) {
  const saved = service.saveAttempt(req.body);

  res.status(201).json({
    message: "Attempt saved",
    data: saved
  });
}

function getAllAttempts(req, res) {
  const attempts = service.getAllAttempts();
  res.json(attempts);
}

function getAttemptsByUser(req, res) {
  const { username } = req.params;
  const attempts = service.getAttemptsByUser(username);
  res.json(attempts);
}

function getAttemptsByQuiz(req, res) {
  const { quizTitle } = req.params;
  const attempts = service.getAttemptsByQuiz(quizTitle);
  res.json(attempts);
}

function markTextAnswer(req, res) {
  const { id, qIndex } = req.params;
  const marks = req.body?.marks;
  console.log(`[attempt.controller] markTextAnswer called id=${id} qIndex=${qIndex} marks=${marks}`);

  try {
    const updated = service.markTextAnswer(id, Number(qIndex), marks);
    if (!updated) {
      console.warn(`[attempt.controller] attempt not found: ${id}`);
      return res.status(404).json({ message: "Attempt not found" });
    }

    // Broadcast the updated attempt so attempters can refresh in real-time
    try {
      ws.broadcast('attempt.updated', updated);
    } catch (e) {
      console.warn('WS broadcast failed', e && e.message);
    }

    return res.json(updated);
  } catch (err) {
    console.error('[attempt.controller] markTextAnswer error', err && err.stack ? err.stack : err);
    return res.status(500).json({ message: 'Failed to apply marks', error: (err && err.message) || String(err) });
  }
}

module.exports = {
  saveAttempt,
  getAllAttempts,
  getAttemptsByUser,
  getAttemptsByQuiz
  ,markTextAnswer
};
