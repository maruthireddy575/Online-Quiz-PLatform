const repository = require("./attempt.repository");
const quizRepository = require("../quiz/quiz.repository");
const domainRepository = require("../domain/domain.repository");

/* Normalize questions - ADD EXPLANATION FIELD */
function normalizeQuestions(questions = []) {
  return questions.map(q => ({
    type: q.type || "mcq",
    text: q.text || "",
    image: q.image || null,
    difficulty: (q.difficulty || "easy").toString().toLowerCase(),
    explanation: q.explanation || "", // 🔥 ADD THIS LINE
    options: (q.options || []).map(opt => {
      if (typeof opt === "string") {
        return { text: opt, image: null };
      }

      return {
        text: opt.text || "",
        image: opt.image || null
      };
    }),
    correctAnswers: q.correctAnswers || [],
    marks: Number(q.marks ?? q.mark ?? q.points ?? 1)
  }));
}

/* Score */
function calculateScore(questions, answers, manualMarks = {}) {
  let score = 0;

  questions.forEach((q, index) => {
    const userAnswer = answers[index];
    const qMarks = Number(q.marks ?? 1);

    if (!q.correctAnswers) return;

    if (q.type === "mcq" || q.type === "image") {
      if (
        userAnswer !== undefined &&
        q.correctAnswers.includes(userAnswer)
      ) score += qMarks;
    }

    else if (q.type === "msq") {
      if (
        Array.isArray(userAnswer) &&
        JSON.stringify([...userAnswer].sort()) ===
        JSON.stringify([...q.correctAnswers].sort())
      ) score += qMarks;
    }

    else if (q.type === "text") {
      // Manual marks take precedence for text answers
      if (manualMarks && Object.prototype.hasOwnProperty.call(manualMarks, index)) {
        const m = Number(manualMarks[index]) || 0;
        score += m;
      } else {
        if (
          typeof userAnswer === "string" &&
          userAnswer.trim().toLowerCase() ===
          (q.correctAnswers[0] || "").trim().toLowerCase()
        ) score += qMarks;
      }
    }
  });

  return score;
}

function normalizeDifficulty(value) {
  if (!value) return "easy";
  const normalized = value.toString().toLowerCase();
  if (["easy", "medium", "hard"].includes(normalized)) {
    return normalized;
  }
  return "easy";
}

function saveAttempt(data) {

  let quizTitle = data.quizTitle;
  let difficulty = data.difficulty;

  // 🔥 USER CREATED QUIZ
  if (typeof data.quizId === "number") {
    const liveQuiz = quizRepository.findById(data.quizId);
    if (liveQuiz) {
      quizTitle = liveQuiz.title;
      difficulty = liveQuiz.difficulty;
    }
  }

  // 🔥 DOMAIN QUIZ
  if (typeof data.quizId === "string") {
    const domainData = domainRepository.readDomain(data.quizId);
    if (domainData) {
      quizTitle = domainData.domain;         // ✅ FORCE correct title
      difficulty = domainData.difficulty;    // ✅ FORCE correct difficulty
    }
  }

  const normalizedQuestions = normalizeQuestions(data.questions);

  const calculatedScore = calculateScore(
    normalizedQuestions,
    data.answers,
    data.manualMarks || {}
  );

  const finalAttempt = {
    id: Date.now(),
    username: data.username,
    quizId: data.quizId ?? null,
    quizTitle: quizTitle || "Untitled Quiz",
    difficulty: normalizeDifficulty(difficulty),
    questions: normalizedQuestions, // ✅ Now includes explanations
    answers: data.answers,
    manualMarks: data.manualMarks || {},
    score: calculatedScore,
    total: normalizedQuestions.reduce((s, q) => s + (Number(q.marks) || 1), 0),
    timestamp: new Date().toISOString()
  };

  repository.save(finalAttempt);
  return finalAttempt;
}

/* Hydration */
function hydrateAttempt(attempt) {

  if (typeof attempt.quizId === "number") {
    const liveQuiz = quizRepository.findById(attempt.quizId);
    if (!liveQuiz) return null;

    const normalizedLive = normalizeQuestions(liveQuiz.questions || []);
    return {
      ...attempt,
      quizTitle: liveQuiz.title,
      difficulty: normalizeDifficulty(liveQuiz.difficulty),
      questions: normalizedLive, // ✅ Now includes explanations
      score: calculateScore(normalizedLive, attempt.answers, attempt.manualMarks || {}),
      total: normalizedLive.reduce((s, q) => s + (Number(q.marks) || 1), 0)
    };
  }

  if (typeof attempt.quizId === "string") {
    const domainData = domainRepository.readDomain(attempt.quizId);
    if (domainData) {
      return {
        ...attempt,
        quizTitle: domainData.domain,
        difficulty: normalizeDifficulty(domainData.difficulty)
      };
    }
  }

  return attempt;
}

function getAllAttempts() {
  return repository.findAll().map(hydrateAttempt).filter(Boolean);
}

function markTextAnswer(attemptId, questionIndex, marks) {
  const attempt = repository.findById(attemptId);
  if (!attempt) return null;

  attempt.manualMarks = attempt.manualMarks || {};
  const qMarks = (attempt.questions && attempt.questions[questionIndex] && Number(attempt.questions[questionIndex].marks)) || 1;
  const m = Math.max(0, Math.min(Number(marks) || 0, qMarks));
  attempt.manualMarks[questionIndex] = m;

  // Recalculate score based on manualMarks
  const normalizedQuestions = attempt.questions || [];
  attempt.score = calculateScore(normalizedQuestions, attempt.answers || [], attempt.manualMarks || {});

  const updated = { ...attempt };
  const ok = repository.updateAttempt(updated);
  if (!ok) return null;
  return hydrateAttempt(updated) || updated;
}

function getAttemptsByUser(username) {
  return repository.findByUser(username).map(hydrateAttempt).filter(Boolean);
}

function getAttemptsByQuiz(quizTitle) {
  return repository.findByQuiz(quizTitle).map(hydrateAttempt).filter(Boolean);
}

module.exports = {
  saveAttempt,
  getAllAttempts,
  getAttemptsByUser,
  getAttemptsByQuiz,
  markTextAnswer
};