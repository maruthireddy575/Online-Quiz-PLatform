const fs = require("fs");
const path = require("path");

const FILE = path.join(
  __dirname,
  "../../database/dynamic/attempts.json"
);

function readAttempts() {
  if (!fs.existsSync(FILE)) {
    fs.writeFileSync(FILE, "[]");
  }

  const raw = JSON.parse(fs.readFileSync(FILE, "utf-8"));

  // Ensure every attempt has a stable numeric id (for older data)
  let changed = false;
  const now = Date.now();
  const normalized = raw.map((a, idx) => {
    if (a.id === undefined || a.id === null) {
      a.id = now + idx;
      changed = true;
    }
    return a;
  });

  if (changed) {
    // Persist assigned ids so future reads are stable
    writeAttempts(normalized);
  }

  return normalized;
}

function writeAttempts(data) {
  fs.writeFileSync(FILE, JSON.stringify(data, null, 2));
}

function save(attempt) {
  const attempts = readAttempts();
  attempts.push(attempt);
  writeAttempts(attempts);
}

function findAll() {
  return readAttempts();
}

function findByUser(username) {
  return readAttempts().filter(a => a.username === username);
}

function findByQuiz(quizTitle) {
  return readAttempts().filter(a => a.quizTitle === quizTitle);
}

function findById(id) {
  return readAttempts().find(a => a.id === id || a.id === Number(id));
}

function updateAttempt(updated) {
  const attempts = readAttempts();
  const idx = attempts.findIndex(a => a.id === updated.id || a.id === Number(updated.id));
  if (idx === -1) return false;
  attempts[idx] = updated;
  writeAttempts(attempts);
  return true;
}

module.exports = {
  save,
  findAll,
  findByUser,
  findByQuiz
};

// Export helper lookups used by services
module.exports.findById = findById;
module.exports.updateAttempt = updateAttempt;
